﻿Meetup Photo Download

Refer to http://code.google.com/p/meetup-photo-download/ for installation and usage information.

Updates 
5/5/2011 - 2.0.0.4
* Correctly uses highres links for download

4/28/2011 - 2.0.0.3
* Removed window size
* MemberId is now looked up based on API key
* Groups are automatically downloaded after updating configuration

